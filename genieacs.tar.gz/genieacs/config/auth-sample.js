exports.connectionRequest = function(deviceId) {
  // return username/password pair for a given device
  return ["", ""];
}
